> 共通適用（2026-10-01）: Config生成標準.jsonの工程別入力条件・7成果物・L0〜L8検証定義を使用する。以下の例示値・構文例は案件の確定値や対応保証ではない。旧validation level表記はConfig検証標準の定義へ対応させ、実施証跡がない項目はnot_runとする。AIは本番適用可・承認済みを宣言しない。

# Cisco_Config.md

> **文書種別**: Cisco機器コンフィグ生成標準・入力テンプレート  
> **schema_version**: 1.0.0  
> **language**: ja-JP  
> **status**: draft  
> **用途**: Microsoft 365 Copilot / Copilot Agent によるCiscoコンフィグ案、投入手順、検証コマンド、ロールバック案の生成  
> **重要**: 本文書は機種横断の生成ルールであり、投入前に対象機種・ソフトウェア版・ライセンス・ハードウェア制約をCisco公式資料と実機または検証環境で確認すること。

---

## 1. 目的

このMarkdownは、Cisco製品の機種・OS・役割・機能差を明示的に判定し、設計パラメータから安全で再現可能なCLIコンフィグ案を生成するための共通仕様である。

生成対象は次の4成果物とする。

1. **事前確認コマンド**
2. **投入用コンフィグ**
3. **事後確認コマンド**
4. **ロールバック用コンフィグまたは復旧手順**

単一の汎用構文を全機種へ流用してはならない。必ず `platform.os_family`、`platform.model`、`platform.software_version`、`platform.operating_mode` を判定し、対応する構文を選択する。

---

## 2. 対応範囲

### 2.1 対応OSファミリ

- Cisco IOS Classic
- Cisco IOS XE
- Cisco NX-OS Standalone
- Cisco IOS XR / IOS XR 64-bit
- Cisco ASA Software
- Cisco Catalyst 9800 Wireless Controller（IOS XE）
- Cisco AireOS Wireless LAN Controller（限定対応）

### 2.2 主な対応製品群

- Catalyst 2960/3560/3750系などのIOSスイッチ
- Catalyst 1000/9200/9300/9400/9500/9600系
- ISR 800/1000/4000系、Catalyst 8000 Edge Platforms
- ASR 1000系
- Nexus 2000/3000/5000/6000/7000/9000系のNX-OSモード
- ASR 9000、NCS 500/540/5500/560/5700、Cisco 8000系
- ASA 5500-X、ASAv、Firepower 1000/2100/3100/4200のASAモード
- Catalyst 9800-CL/40/80/L/F、組み込み9800
- AireOS WLC 2504/3504/5508/5520/8510/8540など

### 2.3 別ワークフローとする対象

以下は本テンプレートから直接CLIを生成せず、専用API、コントローラ、ポリシーまたは管理プレーン向けテンプレートを使う。

- Cisco ACI: APIC REST API / Ansible / Terraform等
- Cisco Meraki: Dashboard API
- Cisco Secure Firewall Threat Defense: FMC/FDM/CDO管理
- Cisco SD-WAN: Catalyst SD-WAN Managerテンプレート/API
- Cisco SD-Access: Catalyst Centerテンプレート/API
- Cisco ISE: ERS/OpenAPIまたはGUIポリシー
- Cisco UCS: UCS Manager/Intersight API
- Nexus Dashboard Fabric Controller管理下のファブリック

対象が上記に該当する場合は、CLI生成を停止して `CONTROLLER_MANAGED_PLATFORM` と報告する。

---

## 3. セキュリティ・ガバナンス

- 機密値を本文へ平文で保存しない。
- パスワード、共有秘密鍵、SNMP認証鍵、TACACS+/RADIUS鍵、VPN PSK、証明書秘密鍵は `${SECRET_NAME}` 形式の参照値にする。
- 実在する顧客IP、ユーザー名、コミュニティ名、鍵をサンプルへ混入させない。
- Telnet、HTTP、SNMPv1/v2c、Type 7相当の弱い保護は、明示承認がない限り生成しない。
- SSH、HTTPS、SNMPv3、AAA、管理ACL、ログ集約、時刻同期を優先する。
- `enable secret`、ローカル管理者、break-glassアカウントの扱いは社内標準に従う。
- 本番投入は必ず人によるレビュー、変更申請、バックアップ、メンテナンス時間、復旧判定条件を伴う。
- 外部AIサービスへ顧客情報、実コンフィグ、秘密情報を入力しない。承認済みのMicrosoft 365 Copilot / Copilot Agent環境内で取り扱う。

---

## 4. 入力必須度

- `REQUIRED`: 未指定なら生成停止
- `CONDITIONAL`: 使用機能に応じて必須
- `OPTIONAL`: 未指定なら安全側の既定値または未生成
- `FORBIDDEN`: 入力・出力禁止

不足時は推測せず、`MISSING_REQUIRED_PARAMETERS` と不足項目一覧を返す。

---

## 5. 共通入力スキーマ

以下のYAMLブロックを複製し、値を設定する。未使用項目は削除せず `null`、`[]`、`false` のいずれかで明示する。

```yaml
metadata:
  schema_version: "1.0.0"
  document_id: "CFG-PROJECT-DEVICE-001"
  project_name: "<PROJECT_NAME>"
  customer_name: "<CUSTOMER_NAME_OR_MASKED>"
  environment: "lab|development|staging|production"
  change_id: "<CHANGE_REQUEST_ID>"
  generated_by: "Microsoft 365 Copilot|Copilot Agent"
  generated_at: "YYYY-MM-DDThh:mm:ss+09:00"
  reviewed_by: []
  approval_status: "draft|reviewed|approved|rejected"

platform:
  vendor: "Cisco"
  hostname: "<HOSTNAME>"                 # REQUIRED
  role: "l2_switch|l3_switch|router|edge_router|core_router|dc_switch|firewall|wlc"
  model: "<EXACT_MODEL>"                 # REQUIRED
  pid: "<PRODUCT_ID_OR_NULL>"
  serial_number: null
  os_family: "ios|ios_xe|nx_os|ios_xr|asa|aireos"  # REQUIRED
  software_version: "<EXACT_VERSION>"    # REQUIRED
  operating_mode: "standalone|stack|stackwise_virtual|vss|vpc|ha|cluster|controller_managed"
  license_level: "<LICENSE_OR_NULL>"
  feature_set: []
  config_register: null
  boot_mode: "install|bundle|null"
  chassis:
    stack_member: null
    supervisor: null
    line_cards: []
    power_supplies: []

output_policy:
  language: "ja-JP"
  line_ending: "LF"
  encoding: "UTF-8"
  include_comments: true
  comment_style: "platform_native"
  include_prechecks: true
  include_postchecks: true
  include_rollback: true
  include_save_command: false
  mask_secrets: true
  fail_on_unsupported_feature: true
  fail_on_ambiguous_interface: true
  preserve_existing_config: true
  idempotent_preferred: true
  destructive_commands_allowed: false
  replacement_mode: "merge|replace|candidate"

site:
  site_code: "<SITE_CODE>"
  timezone: "Asia/Tokyo"
  domain_name: "example.invalid"
  dns_servers: []
  ntp_servers: []
  syslog_servers: []
  snmp_managers: []
  aaa_servers: []
  management_networks: []

system:
  hostname: "<HOSTNAME>"
  domain_name: "example.invalid"
  timezone:
    name: "JST"
    offset_hours: 9
    offset_minutes: 0
  clock_summer_time: null
  ip_routing: true
  ipv6_unicast_routing: false
  password_encryption_service: null
  banners:
    login: "<AUTHORIZED_ACCESS_ONLY>"
    motd: null
  services:
    ssh: true
    scp: true
    https: false
    http: false
    telnet: false
    finger: false
    pad: false
    tcp_small_servers: false
    udp_small_servers: false
    cdp: true
    lldp: true

users:
  local_accounts:
    - username: "${BREAKGLASS_USER}"
      privilege: 15
      role: "network-admin"
      secret_ref: "${BREAKGLASS_SECRET}"
  enable_secret_ref: "${ENABLE_SECRET}"
  password_policy:
    min_length: 14
    complexity: true
    history: null
    lifetime_days: null

management:
  vrf: "<MGMT_VRF_OR_NULL>"
  interface: "<MGMT_INTERFACE_OR_NULL>"
  ipv4_address: "<IP_OR_NULL>"
  ipv4_prefix_length: null
  ipv4_gateway: "<GATEWAY_OR_NULL>"
  ipv6_address: null
  ipv6_prefix_length: null
  source_interfaces:
    ssh: null
    snmp: null
    syslog: null
    ntp: null
    tacacs: null
    radius: null
  access_policy:
    ipv4_acl_name: "MGMT-ACCESS-V4"
    ipv6_acl_name: "MGMT-ACCESS-V6"
    permitted_prefixes: []
  vty:
    exec_timeout_minutes: 10
    transport_input: ["ssh"]
    login_authentication: "AAA-LOGIN"

ssh:
  version: 2
  key_type: "rsa|ecdsa"
  modulus: 3072
  source_interface: null
  algorithms:
    ciphers: []
    macs: []
    key_exchanges: []

ntp:
  enabled: true
  vrf: null
  source_interface: null
  authenticate: false
  trusted_keys: []
  servers:
    - address: "192.0.2.10"
      prefer: true
      key_id: null

logging:
  enabled: true
  buffered_severity: "informational"
  trap_severity: "informational"
  console_severity: "warnings"
  monitor_severity: "warnings"
  facility: "local7"
  source_interface: null
  vrf: null
  timestamp_datetime_msec_localtime: true
  servers:
    - address: "192.0.2.20"
      protocol: "udp"
      port: 514

snmp:
  enabled: true
  versions: ["v3"]
  location: "<LOCATION>"
  contact: "<CONTACT>"
  views: []
  groups:
    - name: "NMS-V3-GROUP"
      version: "v3"
      security_level: "priv"
      read_view: null
      write_view: null
      access_acl: "MGMT-ACCESS-V4"
  users:
    - username_ref: "${SNMPV3_USER}"
      group: "NMS-V3-GROUP"
      auth_protocol: "sha"
      auth_secret_ref: "${SNMPV3_AUTH_SECRET}"
      priv_protocol: "aes-256"
      priv_secret_ref: "${SNMPV3_PRIV_SECRET}"
  trap_hosts: []
  enabled_traps: []
  communities: []

aaa:
  enabled: true
  method: "tacacs+|radius|local"
  new_model: true
  servers:
    - name: "AAA01"
      address: "192.0.2.30"
      protocol: "tacacs+"
      port: 49
      vrf: null
      key_ref: "${TACACS_KEY}"
  server_groups:
    - name: "TACACS-GROUP"
      protocol: "tacacs+"
      servers: ["AAA01"]
  method_lists:
    login: ["group TACACS-GROUP", "local"]
    enable: ["group TACACS-GROUP", "enable"]
    exec_authorization: ["group TACACS-GROUP", "local"]
    command_authorization_15: ["group TACACS-GROUP", "local"]
    exec_accounting: ["start-stop group TACACS-GROUP"]
    command_accounting_15: ["start-stop group TACACS-GROUP"]

vrfs:
  - name: "MGMT"
    description: "Management VRF"
    rd: null
    address_families: ["ipv4"]
    route_targets_import: []
    route_targets_export: []

vlans:
  - id: 10
    name: "USER"
    state: "active"
    vn_segment: null
  - id: 20
    name: "SERVER"
    state: "active"
    vn_segment: null

interfaces:
  - name: "<CANONICAL_INTERFACE_NAME>"
    description: "<DESCRIPTION>"
    enabled: true
    type: "physical|svi|loopback|port_channel|subinterface|tunnel|management"
    mtu: null
    speed: null
    duplex: null
    negotiation: null
    l2:
      enabled: true
      mode: "access|trunk|dot1q_tunnel|routed"
      access_vlan: 10
      native_vlan: null
      allowed_vlans: []
      voice_vlan: null
      trunk_encapsulation: null
    l3:
      enabled: false
      vrf: null
      ipv4_addresses: []
      ipv6_addresses: []
      unnumbered_interface: null
      redirects: false
      proxy_arp: false
    channel_group:
      id: null
      protocol: "lacp|pagp|static|null"
      mode: "active|passive|desirable|auto|on|null"
    spanning_tree:
      portfast: false
      bpduguard: false
      bpdufilter: false
      guard: null
      cost: null
      port_priority: null
    security:
      port_security: false
      maximum_mac: null
      violation: null
      sticky: false
      dhcp_snooping_trust: false
      arp_inspection_trust: false
      ip_source_guard: false
      ipv4_acl_in: null
      ipv4_acl_out: null
      ipv6_acl_in: null
      ipv6_acl_out: null
    qos:
      service_policy_input: null
      service_policy_output: null
      trust: null
    discovery:
      cdp: true
      lldp_tx: true
      lldp_rx: true

port_channels:
  - id: 1
    description: "UPLINK-LAG"
    protocol: "lacp"
    min_links: null
    vpc_id: null
    members: []
    l2:
      mode: "trunk"
      native_vlan: null
      allowed_vlans: [10, 20]

svis:
  - vlan_id: 10
    description: "USER-GW"
    enabled: true
    vrf: null
    ipv4_address: "198.51.100.1"
    ipv4_prefix_length: 24
    ipv6_addresses: []
    standby:
      protocol: "hsrp|vrrp|glbp|null"
      group: 10
      virtual_ipv4: "198.51.100.254"
      priority: 110
      preempt: true
      preempt_delay_seconds: 60
      authentication_ref: null
      track_objects: []
    dhcp_relay_addresses: []
    pim_mode: null

spanning_tree:
  mode: "rapid-pvst|pvst|mst|rstp"
  priority_by_vlan: {}
  root_guard_default: false
  loop_guard_default: false
  etherchannel_guard_misconfig: true
  portfast_default: false
  bpduguard_default: false
  mst:
    region_name: null
    revision: null
    instances: []

layer2_security:
  dhcp_snooping:
    enabled: false
    vlans: []
    database_url: null
  dynamic_arp_inspection:
    enabled: false
    vlans: []
  ip_source_guard:
    enabled: false
  storm_control_defaults:
    broadcast_percent: null
    multicast_percent: null
    unicast_percent: null

static_routes:
  ipv4:
    - vrf: null
      prefix: "0.0.0.0/0"
      next_hop: "192.0.2.1"
      outgoing_interface: null
      administrative_distance: 1
      name: "DEFAULT"
      track: null
  ipv6: []

tracking:
  objects:
    - id: 1
      type: "ip_sla_reachability"
      target_id: 1
  ip_sla:
    - id: 1
      operation: "icmp-echo"
      target: "192.0.2.1"
      source_interface: null
      frequency_seconds: 10
      timeout_ms: 1000
      schedule: "life forever start-time now"

routing:
  ospf:
    processes: []
  ospfv3:
    processes: []
  bgp:
    instances: []
  eigrp:
    processes: []
  isis:
    instances: []
  rip:
    processes: []
  multicast:
    pim: []
    rp_addresses: []
  redistribution: []

route_policy:
  prefix_lists: []
  community_lists: []
  as_path_lists: []
  route_maps: []
  ios_xr_route_policies: []

acls:
  ipv4: []
  ipv6: []
  mac: []
  time_ranges: []

nat:
  enabled: false
  inside_interfaces: []
  outside_interfaces: []
  rules: []
  pools: []

qos:
  class_maps: []
  policy_maps: []
  table_maps: []
  service_policies: []

high_availability:
  type: "none|stack|stackwise_virtual|vss|vpc|hsrp|vrrp|glbp|asa_failover|xr_redundancy"
  peer:
    hostname: null
    peer_link_interfaces: []
    keepalive_source: null
    keepalive_destination: null
  dual_active_detection: null

mpls:
  enabled: false
  ldp: null
  segment_routing: null
  l2vpn: []
  l3vpn: []

vxlan_evpn:
  enabled: false
  source_loopback: null
  anycast_gateway_mac: null
  nve_interface: null
  vnis: []
  bgp_evpn: null

telemetry:
  netflow:
    exporters: []
    monitors: []
    samplers: []
    interface_bindings: []
  model_driven_telemetry:
    subscriptions: []
  span_sessions: []

programmability:
  netconf: false
  restconf: false
  gnmi: false
  grpc: false
  nxapi: false
  guestshell: false
  yang_push: false

wireless:
  management_interface: null
  country_codes: []
  site_tags: []
  policy_tags: []
  rf_tags: []
  wlan_profiles: []
  policy_profiles: []
  flex_profiles: []
  aps: []
  radius_servers: []

asa:
  context_mode: "single|multiple|null"
  firewall_mode: "routed|transparent|null"
  interfaces: []
  name_objects: []
  network_objects: []
  service_objects: []
  object_groups: []
  access_lists: []
  access_groups: []
  nat_rules: []
  routes: []
  inspection_policy: null
  threat_detection: null
  failover: null
  vpn:
    site_to_site: []
    remote_access: []

operations:
  backup_destination: "<APPROVED_REPOSITORY>"
  maintenance_window: "YYYY-MM-DDThh:mm:ss+09:00/YYYY-MM-DDThh:mm:ss+09:00"
  expected_impact: "none|control_plane_reset|port_flap|routing_convergence|reboot"
  max_allowed_outage_minutes: 0
  success_criteria: []
  stop_conditions: []
  rollback_trigger_conditions: []
```

---

## 6. ルーティング入力詳細

### 6.1 OSPF

```yaml
routing:
  ospf:
    processes:
      - process_id: "1"
        vrf: null
        router_id: "192.0.2.101"
        passive_interface_default: true
        no_passive_interfaces: ["<UPLINK_INTERFACE>"]
        reference_bandwidth_mbps: 100000
        default_information_originate: false
        maximum_paths: 4
        areas:
          - area_id: "0.0.0.0"
            type: "normal|stub|totally_stub|nssa|totally_nssa"
            authentication: "none|simple|message_digest"
        networks:
          - prefix: "198.51.100.0/24"
            area: "0.0.0.0"
        interface_settings: []
```

### 6.2 BGP

```yaml
routing:
  bgp:
    instances:
      - local_as: 65000
        vrf: null
        router_id: "192.0.2.101"
        log_neighbor_changes: true
        graceful_restart: false
        address_families:
          - afi_safi: "ipv4_unicast|ipv6_unicast|vpnv4|vpnv6|l2vpn_evpn"
            networks: []
            aggregate_addresses: []
            maximum_paths: 1
        neighbors:
          - address: "192.0.2.102"
            remote_as: 65001
            description: "EBGP-PEER"
            peer_group: null
            update_source: null
            ebgp_multihop: null
            password_ref: "${BGP_PEER_SECRET}"
            timers: null
            bfd: false
            next_hop_self: false
            route_map_in: null
            route_map_out: null
            prefix_list_in: null
            prefix_list_out: null
            maximum_prefix:
              limit: 1000
              threshold_percent: 80
              action: "warning-only"
            activate_address_families: ["ipv4_unicast"]
```

### 6.3 EIGRP / IS-IS

```yaml
routing:
  eigrp:
    processes:
      - mode: "classic|named"
        as_number: 100
        name: null
        vrf: null
        router_id: "192.0.2.101"
        passive_interface_default: true
        no_passive_interfaces: []
        networks: []
        address_families: []
  isis:
    instances:
      - tag: "CORE"
        vrf: null
        net: "49.0001.1920.0000.0101.00"
        level: "level-1|level-2|level-1-2"
        metric_style: "wide"
        router_id: "192.0.2.101"
        interfaces: []
```

---

## 7. ACL・ポリシー入力詳細

```yaml
acls:
  ipv4:
    - name: "MGMT-ACCESS-V4"
      type: "standard|extended"
      remarks: ["Permit approved management networks only"]
      entries:
        - sequence: 10
          action: "permit"
          protocol: "tcp"
          source: "203.0.113.0/24"
          source_port: null
          destination: "host 192.0.2.100"
          destination_port: "eq 22"
          options: ["log"]
        - sequence: 999
          action: "deny"
          protocol: "ip"
          source: "any"
          destination: "any"
          options: ["log"]
route_policy:
  prefix_lists:
    - name: "PL-OUT"
      address_family: "ipv4"
      entries:
        - sequence: 10
          action: "permit"
          prefix: "198.51.100.0/24"
          ge: null
          le: null
  route_maps:
    - name: "RM-BGP-OUT"
      clauses:
        - sequence: 10
          action: "permit"
          match:
            prefix_lists: ["PL-OUT"]
          set:
            local_preference: null
            metric: null
            community: null
            as_path_prepend: null
```

**生成規則**

- ACLは暗黙のdenyを考慮する。
- 既存ACLへ行番号なしで追記しない。
- IOS/IOS XE/NX-OS/ASA/IOS XRで異なるACL構文を混在させない。
- IOS XRではprefix-set、community-set、as-path-set、route-policyを優先する。
- 管理ACLは装置自身への管理アクセス用と転送トラフィック用を分離する。

---

## 8. OS別生成ルール

### 8.1 IOS / IOS XE

- 設定モードは通常 `configure terminal` を使用する。
- VLAN、SVI、switchport、Port-channel、HSRP、VRRP、StackWise Virtual、ルーティング、MQCを役割と対応機能に応じて生成する。
- IOS XEルータとCatalystスイッチで同一機能名でも構文・既定値・対応範囲が異なるため、`model` と `software_version` を必須とする。
- Catalyst 9000ではインターフェース名、スタックメンバー番号、Network Advantage/Essentials等のライセンス差を確認する。
- 保存操作は明示承認時のみ `copy running-config startup-config` を別セクションに出力する。
- コンフィグ置換機能を使う場合は、通常のmerge投入と分ける。

### 8.2 NX-OS

- 使用機能は必要に応じて `feature <name>` または対応する機能有効化を先に生成する。
- 管理VRF、`mgmt0`、vPC、NVE、EVPN、VRF context、checkpoint/rollbackのNX-OS固有構文を使う。
- `switchport trunk allowed vlan` の置換・追加・削除意味を明確にし、意図しないVLAN消失を防止する。
- vPC変更は両peerの整合性、peer-link、keepalive、role、consistency parameterを事前確認する。
- ACIモード機器にはNX-OS standalone用CLIを生成しない。

### 8.3 IOS XR

- 候補コンフィグ方式を前提にし、生成物末尾に `commit` を自動付与しない。承認された実行手順へ `commit confirmed`、`commit label`、通常commit等を明示する。
- `router ospf`、`router bgp`、address-family、VRF、route-policy language、interface bundle、L2VPN、MPLS、Segment RoutingのXR構文を使う。
- `show configuration changes diff`、`show configuration failed`、commit履歴などの確認を組み込む。
- XR 32-bit/64-bit、装置ファミリ、リリースでパッケージ・機能差があるため厳密照合する。

### 8.4 ASA

- ASA OSとFTD OSを混同しない。FTDの場合はCLI生成停止。
- routed/transparent、single/multiple context、active/standby/clusterを必ず判定する。
- object network、object-group、ACL、access-group、8.3以降のNAT構文、MPF、failover、VPNをセクション分離する。
- NATとACLの評価対象アドレス、適用方向、順序、sectionを明記する。
- `write memory` は自動生成せず、保存手順を分離する。
- VPN秘密鍵、PSK、証明書秘密鍵を平文で出力しない。

### 8.5 Catalyst 9800 WLC

- IOS XEベースだが、WLAN profile、policy profile、policy tag、site tag、RF tagの関連付けを前提とする。
- AP join、CAPWAP source、wireless management interface、AAA、FlexConnect、HA SSOの依存関係を検証する。
- GUIで生成された構文の単純転用はせず、対象リリースのCLI仕様を確認する。

### 8.6 AireOS WLC

- AireOS専用CLIを使い、IOS XE構文を混在させない。
- コマンドが対話式か即時反映かを明示する。
- 旧機種・旧リリースでは機能差およびサポート終了状況を確認する。

---

## 9. 機能依存関係

生成前に最低限、次を検査する。

1. SVIには対象VLANが存在すること。
2. access VLAN、native VLAN、allowed VLANがVLAN定義または許可方針と整合すること。
3. Port-channelメンバーの速度、MTU、L2/L3モード、trunk条件が一致すること。
4. HSRP/VRRP/GLBPのVIPが接続サブネット内にあり、実IPと重複しないこと。
5. OSPF/BGP/IS-ISのrouter-idが一意で到達可能な設計であること。
6. BGP neighborのaddress-family activationが明示されていること。
7. route-mapが参照するprefix-list/community-listが存在すること。
8. ACLの参照オブジェクト、object-group、time-rangeが存在すること。
9. source-interfaceが対象VRF内で到達可能であること。
10. AAA障害時のfallbackとbreak-glass経路が確保されていること。
11. SNMPv3 user/group/view/security-levelが整合すること。
12. DHCP snooping、DAI、IP Source Guardのbinding依存を満たすこと。
13. vPC/VSS/StackWise Virtual/HA peer間で対称設定が要求される項目を識別すること。
14. VXLAN VNI、VLAN、VRF、route-target、NVE、BGP EVPNの対応が一意であること。
15. MPLS/LDP/SRのrouter-id、IGP、ラベル配布・SID設計が整合すること。
16. ASA NAT、ACL、route、VPN interesting trafficが相互に矛盾しないこと。
17. WLCのWLAN、policy profile、tag、AP割当が完全であること。

---

## 10. 禁止ルール

次の場合はコンフィグを生成せず、エラーとして返す。

- OSファミリ、モデル、厳密なソフトウェア版のいずれかが不明
- 実インターフェース名を推定する必要がある
- コントローラ管理対象へ直接CLIを投入する要求
- 未対応機能を別OSの類似構文で代替しようとする要求
- 秘密値の平文埋め込み要求
- 全許可ACL、認証なし管理アクセス、遠隔Telnetなど、明示承認のない危険設定
- 既存設定を確認せずVLAN allowed list、ACL、route-policy、NAT、AAAを全面置換する要求
- `reload`、`write erase`、`erase startup-config`、`format`、`factory-reset`、大量の`default interface`など破壊的操作
- IOS XRの無条件commit、NX-OS/IOSの無条件保存、ASAの無条件write memory
- 構文妥当性を保証できない機能またはリリース

---

## 11. 出力フォーマット

生成結果は必ず次の順序とする。

```text
00_Generation_Report.md
01_PreCheck.txt
02_Configuration.txt
03_PostCheck.txt
04_Rollback.txt
05_ChangeProcedure.md
06_ReferenceEvidence.md
```

### 11.1 Generation Report

```yaml
generation_report:
  result: "success|warning|failed"
  target:
    hostname: "<HOSTNAME>"
    model: "<MODEL>"
    os_family: "<OS_FAMILY>"
    software_version: "<VERSION>"
  assumptions: []
  missing_parameters: []
  unsupported_features: []
  warnings: []
  secret_references: []
  destructive_changes: []
  service_impact: []
  official_documentation_to_verify: []
```

### 11.2 投入用コンフィグ

- CLIコマンドだけをコードブロックへ出力する。
- 説明はコードブロック外に置く。
- 秘密値は `${...}` のまま残す。
- `show` コマンドを投入用コンフィグへ混ぜない。
- 保存、commit、reloadなど実行確定操作は別セクションにする。

### 11.3 ロールバック

ロールバックは次の優先順位で生成する。

1. プラットフォーム標準のcheckpoint/rollbackまたはcommit rollback
2. 変更差分を逆順に戻すCLI
3. 事前バックアップからの復元手順

「変更前状態が不明」な項目は、推測した `no` コマンドを生成せず、`ROLLBACK_REQUIRES_PRECHANGE_STATE` とする。

---

## 12. 事前確認コマンド生成方針

### IOS / IOS XEの代表カテゴリ

```text
show version
show inventory
show license summary
show running-config
show startup-config
show ip interface brief
show ipv6 interface brief
show interfaces status
show interfaces trunk
show etherchannel summary
show vlan brief
show spanning-tree summary
show ip route
show ip ospf neighbor
show bgp all summary
show standby brief
show logging
show clock detail
show ntp associations
show aaa servers
```

### NX-OSの代表カテゴリ

```text
show version
show inventory
show feature
show running-config
show interface brief
show interface status
show vlan brief
show port-channel summary
show vpc brief
show spanning-tree summary
show vrf
show ip route
show ip ospf neighbors
show bgp all summary
show nve peers
show logging last 100
show clock
show ntp peers
show checkpoint summary
```

### IOS XRの代表カテゴリ

```text
show version
show inventory
show platform
show running-config
show configuration commit list
show interfaces brief
show ipv4 interface brief
show route summary
show ospf neighbor
show bgp summary
show redundancy summary
show logging
show clock
show ntp associations
```

### ASAの代表カテゴリ

```text
show version
show inventory
show mode
show context
show failover
show running-config
show interface ip brief
show route
show access-list
show access-group
show nat detail
show xlate
show conn count
show service-policy
show logging
show clock
```

実際の出力では、対象OS・リリースで有効なコマンドだけを選ぶ。

---

## 13. 事後確認と成功判定

事後確認には最低限、次を含める。

- 対象セクションのrunning-config確認
- インターフェースline/protocol状態
- エラーカウンタ、discard、CRC、drops
- VLAN/trunk/Port-channel/STP/vPC等のL2状態
- ARP/ND、経路、隣接、FHRP状態
- OSPF/BGP/IS-IS/EIGRP隣接および受信経路数
- 管理VRFからNTP/Syslog/AAA/SNMP宛て到達性
- ログに新規重大エラーがないこと
- CPU、メモリ、プロセス、HA状態
- 対象通信の疎通。source/VRFを明示すること
- 変更前後差分

成功条件は曖昧な「正常」ではなく、数値または期待状態で定義する。

```yaml
operations:
  success_criteria:
    - "All intended interfaces are up/up"
    - "Port-channel members are bundled"
    - "OSPF neighbor state is FULL"
    - "BGP neighbor state is Established"
    - "No new severity 0-3 logs after change"
    - "Management reachability succeeds from approved source"
  stop_conditions:
    - "Loss of management connectivity"
    - "Unexpected routing adjacency reset"
    - "HA peer state becomes failed"
  rollback_trigger_conditions:
    - "Success criteria not met within 10 minutes"
```

---

## 14. コンフィグ生成順序

依存関係を考慮し、原則として次の順に生成する。

1. プラットフォーム判定とfeature/license確認
2. システム基本設定
3. VRF
4. 管理インターフェースと管理経路
5. ローカルユーザー、AAA、SSH、管理ACL
6. NTP、DNS、Syslog、SNMP
7. VLAN
8. Port-channelと物理インターフェース
9. SVI、loopback、L3インターフェース
10. STPとL2セキュリティ
11. ACL、object、prefix-list、route-policy
12. 静的経路、FHRP
13. IGP、BGP、再配送
14. QoS、NetFlow、telemetry
15. MPLS、L2VPN、L3VPN、VXLAN EVPN
16. HA固有設定
17. WirelessまたはASA固有設定
18. 事後確認
19. 保存またはcommitの承認済み手順

削除時は原則として依存関係の逆順とする。

---

## 15. 差分生成ルール

- `desired_state` と `current_state` を比較して差分だけを生成する。
- 現行コンフィグ未提示時は、追加が安全な項目のみ生成する。
- リスト型コマンドは `replace`、`add`、`remove` を区別する。
- ACL、VLAN allowed list、route-policy、object-group、NAT、WLC tag関連は全置換リスクを警告する。
- コマンドの存在だけでなく、順序、sequence、適用方向、VRF、address-familyも比較する。
- 装置が自動正規化するコンフィグ表示差を誤差分と判定しない。

```yaml
change_set:
  current_state_source: "running-config|golden-config|unknown"
  desired_state_source: "design-parameters"
  mode: "merge|replace|candidate"
  additions: []
  modifications: []
  removals: []
  unchanged: []
```

---

## 16. 検証レベル

```yaml
validation:
  level: "L0_input|L1_identity|L2_reference|L3_syntax|L4_semantic|L5_delta|L6_lab|L7_human_review|L8_approved"
  checks:
    syntax: true
    references: true
    address_overlap: true
    duplicate_router_id: true
    duplicate_ip: true
    vlan_consistency: true
    port_channel_consistency: true
    routing_policy_reachability: true
    aaa_fallback: true
    secret_masking: true
    license_support: true
    hardware_support: true
    software_release_support: true
    peer_symmetry: true
```

検証レベルはConfig検証標準.jsonのL0_input〜L8_approvedを使用する。AIが記録できるのは実施根拠があるL0〜L5の確認結果まで。L6には実試験証跡、L7/L8には人のレビュー・承認記録が必要。

---

## 17. 生成エラーコード

- `MISSING_REQUIRED_PARAMETERS`
- `UNKNOWN_PLATFORM`
- `UNKNOWN_SOFTWARE_VERSION`
- `AMBIGUOUS_INTERFACE_NAME`
- `UNSUPPORTED_FEATURE`
- `LICENSE_NOT_CONFIRMED`
- `HARDWARE_CAPABILITY_NOT_CONFIRMED`
- `CONTROLLER_MANAGED_PLATFORM`
- `SECRET_IN_PLAINTEXT`
- `DESTRUCTIVE_CHANGE_BLOCKED`
- `CURRENT_STATE_REQUIRED`
- `DEPENDENCY_VALIDATION_FAILED`
- `PEER_CONFIGURATION_REQUIRED`
- `ADDRESS_CONFLICT`
- `ROLLBACK_REQUIRES_PRECHANGE_STATE`
- `OFFICIAL_DOCUMENTATION_VERIFICATION_REQUIRED`

---

## 18. AIエージェント向けシステム指示

```text
You are a Cisco configuration generation agent operating only in an approved Microsoft 365 Copilot or Copilot Agent environment.

1. Parse all input fields and normalize model, OS family, software version, role, operating mode, interface names, VRFs, address families, and feature dependencies.
2. Never guess a model, release, license, interface name, secret, IP address, VLAN, ASN, routing policy, or HA peer value.
3. Stop when required values are missing or the target is controller-managed.
4. Select exactly one primary syntax family: IOS, IOS XE, NX-OS, IOS XR, ASA, or AireOS. Catalyst 9800 uses IOS XE wireless syntax.
5. Do not mix command families.
6. Check feature, license, hardware, mode, and release compatibility against approved Cisco documentation available in the connected enterprise knowledge source.
7. Generate a report, prechecks, configuration, postchecks, rollback, and change procedure.
8. Keep secrets as ${SECRET_REFERENCE}. Never reveal or invent secrets.
9. Do not include save, commit, reload, erase, reset, or destructive commands in the main configuration.
10. For IOS XR, separate candidate configuration from commit procedure.
11. For NX-OS, verify feature enablement and vPC consistency.
12. For ASA, verify ASA versus FTD, routed versus transparent, context mode, NAT order, ACL direction, and HA mode.
13. Prefer secure management protocols. Reject Telnet, cleartext secrets, unrestricted management access, and SNMPv1/v2c unless an approved exception is explicitly supplied.
14. Generate only the desired delta when current state is available. If current state is unavailable, avoid unsafe replacement commands.
15. Mark every assumption, warning, unsupported item, service impact, and manual verification item.
16. Never claim production readiness. A human reviewer must approve and test the output.
17. Output commands exactly as supported by the identified target. If support cannot be verified, return OFFICIAL_DOCUMENTATION_VERIFICATION_REQUIRED instead of fabricating syntax.
```

---

## 19. 利用プロンプト

```text
添付または接続された Cisco_Config.md の規則に厳密に従ってください。
入力パラメータと現行コンフィグを解析し、対象プラットフォームを特定してください。
不足値、曖昧値、非対応機能、ライセンス未確認、破壊的変更がある場合はコンフィグ生成を停止し、エラーコードと不足一覧を返してください。

次の成果物を順番に生成してください。
1. 00_Generation_Report.md
2. 01_PreCheck.txt
3. 02_Configuration.txt
4. 03_PostCheck.txt
5. 04_Rollback.txt
6. 05_ChangeProcedure.md

秘密値は ${SECRET_REFERENCE} のままとし、保存、commit、reload、erase系コマンドを投入用コンフィグへ含めないでください。
```

---

## 20. レビュー・チェックリスト

### プラットフォーム

- [ ] 正確なモデル/PIDを確認した
- [ ] OSファミリと厳密なバージョンを確認した
- [ ] operating modeを確認した
- [ ] 必要ライセンスを確認した
- [ ] ハードウェア制限、TCAM、scale、ポート能力を確認した
- [ ] コントローラ管理対象でないことを確認した

### 設計整合

- [ ] IP/VLAN/VRF/ASN/router-id/VNIが一意である
- [ ] インターフェース名と収容位置が正しい
- [ ] L2/L3/Port-channel/MTUが両端で整合する
- [ ] routing policyと再配送にループがない
- [ ] FHRPとtrackingが期待どおりである
- [ ] HA peerとの対称性を確認した

### セキュリティ

- [ ] 秘密値がマスクされている
- [ ] 管理面がSSH/HTTPS/SNMPv3で保護される
- [ ] 管理ACLとAAA fallbackがある
- [ ] 不要サービスが無効である
- [ ] ログ、NTP、監視が定義されている
- [ ] ACL/NAT/route-policyの順序と方向が正しい

### 変更作業

- [ ] 事前バックアップを取得する
- [ ] 事前確認結果を保存する
- [ ] 影響、停止条件、成功条件を定義した
- [ ] ロールバックを検証した
- [ ] 保存/commit/reloadは別承認である
- [ ] 作業後の差分とログを保管する

---

## 21. 推奨ファイル配置

```text
/Network-AI/
├── 00_Governance/
│   ├── AI_Usage_Policy.md
│   └── Secret_Handling_Policy.md
├── 01_Templates/
│   └── Cisco/
│       ├── Cisco_Config.md
│       ├── Platform_Capability_Matrix.yaml
│       └── Validation_Rules.yaml
├── 02_Input/
│   ├── Design_Parameters.yaml
│   └── Current_Configuration_masked.txt
├── 03_Output/
│   └── <CHANGE_ID>/
│       ├── 00_Generation_Report.md
│       ├── 01_PreCheck.txt
│       ├── 02_Configuration.txt
│       ├── 03_PostCheck.txt
│       ├── 04_Rollback.txt
│       └── 05_ChangeProcedure.md
└── 04_Evidence/
    └── <CHANGE_ID>/
        ├── Precheck_Result.txt
        ├── Postcheck_Result.txt
        ├── Config_Diff.txt
        └── Approval_Record.pdf
```

SharePointでは、テンプレートを承認済み読み取り専用領域へ置き、入力、生成物、承認記録、作業証跡を分離する。実コンフィグは権限制御・監査・秘密情報除去の対象とする。

---

## 22. 公式資料確認先

生成時点の対象モデル・OS・リリースに対応するCisco公式のConfiguration Guide、Command Reference、Release Notes、Feature Navigator/Feature Finder、ライセンス資料、Field Notice、Security Advisoryを確認する。

- Cisco IOS XE Configuration Guides
- Cisco NX-OS Configuration Guides
- Cisco IOS XR Configuration Guides
- Cisco Secure Firewall ASA Configuration Guides
- 対象製品別Release Notes
- 対象OS別Software Hardening Guide

本テンプレート内の例示値・代表showコマンドは、全モデル・全リリースでの動作を保証しない。

---

## 23. 改訂履歴

| Version | Date | Status | Description |
|---|---|---|---|
| 1.0.0 | 2026-09-04 | Draft | 機種横断スキーマ、OS別ルール、検証、差分、ロールバック、AI指示を統合 |
