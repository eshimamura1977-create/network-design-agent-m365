> 共通適用（2026-10-01）: Config生成標準.jsonの工程別入力条件・7成果物・L0〜L8検証定義を使用する。以下の例示値・構文例は案件の確定値や対応保証ではない。旧validation level表記はConfig検証標準の定義へ対応させ、実施証跡がない項目はnot_runとする。AIは本番適用可・承認済みを宣言しない。

# FortiGate Config生成プロンプト

## 1. 目的
Fortinet FortiGate機器について、設計パラメータ、現行Config、実機証跡、対象版の公式資料を照合し、差分Config案を安全に生成する。

## 2. 対象OS・管理方式
- FortiOS
- FortiManager管理時は別ワークフロー

## 3. 必須入力
- 正確な型式/PID
- OSファミリと完全なVersion/Rev/build
- 動作モード、License、搭載構成
- 現行Config
- Version、Inventory、Interfaceの実機出力
- 設計パラメータ、成功条件、停止条件、Rollback条件

## 4. 公式情報源
- docs.fortinet.com CLI Reference
- Administration Guide
- Release Notes
- Hardware Guide
- Upgrade Path/Maximum Values
検索結果の要約だけを根拠にせず、対象型式・対象版の原文を確認する。

## 5. 実機証跡
```text
get system status
get hardware status
get system interface physical
show full-configuration
tree
```

## 6. 固有ルール
- model、FortiOS version、build、VDOM、operation mode、HA modeを確定
- policy/NAT/VIP/IPsecの参照と順序を検証
- FortiManager管理時はローカル変更の上書きリスクを判定

## 7. 共通禁止事項
- 不明値、Interface、License、機能対応を推測しない。
- 異なるOS構文を混在させない。
- 平文秘密情報を出力しない。`${SECRET_REFERENCE}`を使用する。
- save、commit、reload、eraseを主Configへ含めない。
- 現行状態不明時に削除、置換、全面更新を生成しない。

## 8. 出力
1. `00_Generation_Report.md`
2. `01_PreCheck.txt`
3. `02_Configuration.txt`
4. `03_PostCheck.txt`
5. `04_Rollback.txt`
6. `05_ChangeProcedure.md`
7. `06_ReferenceEvidence.md`

## 9. 停止条件
`MISSING_REQUIRED_PARAMETERS`、`UNKNOWN_SOFTWARE_VERSION`、`AMBIGUOUS_INTERFACE_NAME`、`OFFICIAL_DOCUMENTATION_VERIFICATION_REQUIRED`、`UNSUPPORTED_FEATURE`、`CONTROLLER_MANAGED_PLATFORM`のいずれかに該当する場合はConfig生成を停止する。
