# Internal Config Standards

## 適用順序
1. 社内情報セキュリティーポリシー・顧客ルール
2. Configセキュリティ標準
3. Config生成標準
4. Config検証標準
5. ベンダー公式仕様
6. 案件固有設計

## 共通方針
- Hostname、Interface description、VLAN、VRF、ACL、Policy、Objectは案件の命名規則に従う。
- 管理はSSH/HTTPS、監視はSNMPv3、認証はAAAを基本とする。
- NTP、Syslog、管理ACL、break-glass、Config backupを設計する。
- 秘密情報は`${SECRET_REFERENCE}`とする。
- 既存設定を保持し、差分生成を基本とする。
- 本資料はベンダー仕様の代替ではない。
