# Known Version Differences

## 目的
機種・OS・Version間の既知差異を、公式根拠と承認者を付けて管理する索引。差異そのものを推測で追記しない。

## 登録書式
- Vendor
- Product family / Model
- From version / To version
- Feature / Command
- Difference type: added / changed / deprecated / removed / defect / hardware-dependent
- Operational impact
- Workaround
- Official source URL and document title
- Checked date / Approved by

## 運用
- Config生成前に対象機器の該当recordを確認する。
- 公式Release Notes、Command Reference、Known Issuesを根拠とする。
- 解消済み項目は削除せずsupersededとして保持する。
